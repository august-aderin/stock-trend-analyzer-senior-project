import sent_anal_3
import ann_lstm_multitrain

def train_model(model, train_ticker, train_start_date, train_end_date):
    model.train_model(train_ticker, train_start_date, train_end_date)
    return model

def analyze_sentiment(ticker):
    sentiment_model = sent_anal_3.SentimentAnalysisModel()
    return sentiment_model.analyze_sentiment(ticker)

def predict_stock_price(model, ticker, start_date, end_date):
    return model.predict_price(ticker, start_date, end_date)

def determine_action(sentiment_breakdown, lstm_result):
    if lstm_result is not None:
        if "Rise" in lstm_result[0]:
            stock_movement = "up"
        elif "Fall" in lstm_result[0]:
            stock_movement = "down"
        else:
            stock_movement = "stagnant"

        
        most_popular_sentiment = max(sentiment_breakdown, key=sentiment_breakdown.get)
        news = most_popular_sentiment
        
        if news == "positive":
            if stock_movement == "up":
                return f"It's strongly recommended that you buy this stock. The news is {news} and the stock price is going {stock_movement}."
            elif stock_movement == "down":
                return f"It is not recommend that you buy this stock. While the news is {news}, the stock price is going {stock_movement}."
            else:
                return f"It's recommended that you buy this stock. While the stock price is {stock_movement}, the news is {news}"
        elif news == "negative":
            if stock_movement == "up":
                return f"It's recommended to cautiously buy this stock. While the stock price is {stock_movement}, the news is {news} "
            elif stock_movement == "down":
                return f"It's strongly recommended that you sell this stock. The news is {news} and the stock price is going {stock_movement}."
            else:
                return f"It's recommended that you sell this stock. While the news is {news}, the stock price is {stock_movement}."
        else:  # Neutral news
            if stock_movement == "up":
                return f"It's recommended that you buy this stock. While the news is {news}, the stock price is going {stock_movement}."
            elif stock_movement == "down":
                return f"It's recommended that you sell this stock. While the news is {news}, the stock price is going {stock_movement}."
            else:
                return f"It's recommended that you watch this stock carefully. The news is {news} and the stock price is {stock_movement}."
    else:
        return "Prediction failed. Please check the inputs and try again."

def main():
    last_trained_ticker = None  # Variable to store the last trained ticker symbol
    model = None  # Initialize model outside the loop
    
    while True:
        train_ticker = input("Enter a ticker to train the model: ")
                
        # Check if the ticker for training is different from the last trained ticker
        if train_ticker != last_trained_ticker or model is None:
            train_start_date = input("Enter the start date for training (YYYY-MM-DD): ")
            train_end_date = input("Enter the end date for training (YYYY-MM-DD): ")
            model = ann_lstm_multitrain.LSTMModel()
            model = train_model(model, train_ticker, train_start_date, train_end_date)
            last_trained_ticker = train_ticker  # Update last trained ticker
            print("Model trained successfully.")
        else:
            print("Using existing model. No need to retrain.")
        
        ticker = input("Enter a ticker symbol: ")
        start_date = input("Enter the start date (YYYY-MM-DD): ")
        end_date = input("Enter the end date (YYYY-MM-DD): ")
        
        sentiment_breakdown = analyze_sentiment(ticker)  # Corrected line
        lstm_result = predict_stock_price(model, ticker, start_date, end_date)
        
        if lstm_result is not None:  # Check if lstm_result is not None
            print("Sentiment Analysis Breakdown:")
            for sentiment, percentage in sentiment_breakdown.items():
                print(f"{sentiment}: {percentage:.2f}%")
            most_popular_sentiment = max(sentiment_breakdown, key=sentiment_breakdown.get)
            print("Most Popular Sentiment:", most_popular_sentiment)
            print("LSTM Model Prediction:", lstm_result)

        action = determine_action(sentiment_breakdown, lstm_result)
        print("Action to take:", action)
        
        exit_choice = input("Do you want to continue (Yes/No)?: ").lower()
        if exit_choice == "no":
            break

if __name__ == '__main__':
    main()
