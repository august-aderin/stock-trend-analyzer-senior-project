import numpy as np
import pandas_datareader as web
import joblib
from joblib import dump, load
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential, load_model
import matplotlib.pyplot as plt
from keras.layers import Dense, LSTM
import yfinance as yf 
import math
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split

plt.style.use('fivethirtyeight')

class LSTMModel:
    def __init__(self, name=None):
            self.model = None
            self.name = name
            self.scaler = None  # Add scaler attribute

    def load_model(self, model_file_path):
        self.model = load_model(model_file_path)

    def load_scaler(self, scaler_file_path):
        self.scaler = joblib.load(scaler_file_path)

    def train_model(self, ticker, start_date, end_date):
        try:
            # Fetch historical data including opening, high, low, close, and volume
            df = yf.download(ticker, start=start_date, end=end_date)
        except ValueError:
            print(f"Error: Failed to download data for {ticker}. Please check the ticker symbol and try again.")
            return
        
        # Preprocess the data to include all relevant features
        dataset = df[['Open', 'High', 'Low','Volume','Close']].values
        print(dataset)

        # Initialize scaler
        self.scaler = MinMaxScaler(feature_range=(0,1))
        
        # Normalize the data
        scaled_data = self.scaler.fit_transform(dataset)

        print("+++++++++")
        print(scaled_data)
        print("+++++++++")
        X = scaled_data[:,0:4]
        print(X)
        print("+++++++++")
        Y= scaled_data[:,4]
        print(Y)
        x_train, x_test, y_train, y_test = train_test_split(X, Y)
        x_train_size = len(x_train)
        print(x_train)
        print(y_train)
        AA = np.size(x_train)
        print("++++++++")

        x_train = x_train.reshape(x_train_size, 1, 4)

        self.model = Sequential([
        LSTM(50, return_sequences=True, input_shape=(1, 4)),
        LSTM(50, return_sequences=False),
        Dense(25, activation='relu'),
        Dense(1, activation='linear')
    ], name='MyLSTMModel')  # Set the name attribute here

        # Compile and train the model
        self.model.compile(optimizer='adam', loss='mean_squared_error')
        self.model.fit(x_train, y_train, batch_size=32, epochs=50)

         # Save the trained model
        self.model.save(f'media/lstm_model.h5')
        # Save the scaler
        scaler_file_path = f'media/scaler.pkl'
        joblib.dump(self.scaler, scaler_file_path)


    def predict_direction(self, pred_price, last_price):
        price_difference = pred_price - last_price
        percentage_difference = (price_difference / last_price) * 100
        
        if abs(percentage_difference) <= 0.5:
            direction = "Stall"
        elif 0.5 < percentage_difference <= 2:
            direction = "Rise" if percentage_difference > 0 else "Fall"
        elif 2 < percentage_difference <= 5:
            direction = "Sharp Rise" if percentage_difference > 0 else "Sharp Fall"
        elif percentage_difference > 5:
            direction = "Significant Rise" if percentage_difference > 0 else "Significant Fall"
        else:
            direction = "Neutral"  # Default direction
            
        return direction


    def predict_price(self, ticker, start_date, end_date):
        if self.model is None:
            print("Error: Model not trained yet.")
            return None, None  # Return None for both direction and price
            
        try:
            # Fetch historical data
            df = yf.download(ticker, start=start_date, end=end_date)

            # Preprocess the data
            dataset = df[['Open', 'High', 'Low', 'Volume', 'Close']].values
            scaled_data = self.scaler.transform(dataset)  # Use the same scaler instance used for training

            A = scaled_data[:,:4]
            print(A)
            print("+++++++++")
            B = scaled_data[:,4]
            print(B)
            x_train, x_test, y_train, y_test = train_test_split(A, B)
            x_test_size = len(x_test)
            print(x_test)
            print(y_test)
            AA = np.size(x_test)
            print("++++++++")
        
            A = A.reshape(A.shape[0], 1, A.shape[1])


            # Make predictions
            predictions = self.model.predict(A)
            print("Shape of predictions:", predictions.shape)  # Print shape of predictions
            predictions = self.scaler.inverse_transform(np.concatenate((A.reshape(A.shape[0], A.shape[2]), predictions), axis=1))[:, -1]  # Use the same scaler instance

            # Get the last actual price
            last_price = df.iloc[-1]['Close']

            # Predict direction
            direction = self.predict_direction(predictions[-1], last_price)

            df = df.loc[start_date:end_date]  # Limiting the data to the specified time range

            # Save plot
            plt.figure(figsize=(16,8))
            plt.title(f'{ticker} Model')
            plt.xlabel('Date', fontsize=18)
            plt.ylabel('Close Price USD ($)', fontsize=18)
            plt.plot(df.index, df['Close'], label='Actual')  # Plot actual closing prices
            plt.plot(df.index, predictions, label='Predicted')  # Plot predicted closing prices
            plt.legend(loc='lower right')
            plot_file_path = f'media/model_plot.png'  # Include ticker symbol in the plot file name
            plt.savefig(plot_file_path)
            plt.close()

            # Save the trained model
            model_file_path = f'media/lstm_model.h5'  # Include ticker symbol in the model file name
            self.model.save(model_file_path)

            predicted_price_formatted = "${:.2f}".format(round(predictions[-1], 2))
            return direction, predicted_price_formatted
        except ValueError:
            print(f"Error: Failed to download data for {ticker}. Please check the ticker symbol and try again.")
            return None, None
        
if __name__ == "__main__":
    model = LSTMModel()
    ticker_to_train = input("Enter a ticker to train the model: ")
    start_date = input("Enter the start date for training (YYYY-MM-DD): ")
    end_date = input("Enter the end date for training (YYYY-MM-DD): ")
    model.train_model(ticker_to_train, start_date, end_date)

    tickers_to_predict = input("Enter tickers separated by commas to predict their directions: ").split(',')
    predict_start_date = input("Enter the start date for prediction (YYYY-MM-DD): ")
    predict_end_date = input("Enter the end date for prediction (YYYY-MM-DD): ")
    for ticker in tickers_to_predict:
        direction, predicted_price = model.predict_price(ticker.strip(), predict_start_date, predict_end_date)
        if direction is not None:
            print(f"Predicted direction for {ticker}: {direction}")
            print(f"Predicted price for {ticker}: {predicted_price}")