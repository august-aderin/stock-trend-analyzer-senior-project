from flask import Flask, render_template, request, redirect, url_for, jsonify, send_file
import json
import requests
import main_page
from ast import literal_eval
import ann_lstm_multitrain
import sent_anal_3

app = Flask(__name__) 

@app.route('/')
def index():
    return render_template('index.php')

@app.route('/train_and_predict')
def train_and_predict():
    return render_template('train_and_predict.php')

@app.route('/info')
def info():
    return render_template('info.php')

@app.route('/trifecta_edit_profile')
def trifecta_edit_profile():
    return render_template('trifecta_edit_profile.php')

@app.route('/trifecta_login')
def trifecta_login():
    return render_template('trifecta_login.php')

@app.route('/trifecta_logout')
def trifecta_logout():
    return render_template('trifecta_logout.php')

@app.route('/trifecta_sign_up')
def trifecta_sign_up():
    return render_template('trifecta_sign_up.php')

@app.route('/database_connection')
def database_connection():
    return render_template('database_connection.php')


@app.route('/train_model', methods=['POST'])
def train_model():
    ticker_to_train = request.form['train_ticker']
    start_date = request.form['train_start_date']
    end_date = request.form['train_end_date']
    model = ann_lstm_multitrain.LSTMModel(name='MyLSTMModel')

    # Train the model using the train_model function from standalone_code
    trained_model = main_page.train_model(model, ticker_to_train, start_date, end_date)
    
    # Convert the trained model into a JSON-serializable format
    model_info = {
        'model_name': trained_model.name,
        'training_ticker': ticker_to_train,
        'start_date': start_date,
        'end_date': end_date
        # Add more model attributes as needed
    }
    
    return jsonify(model=model_info)

@app.route('/predict_stock', methods=['POST'])
def predict_stock():
    ticker = request.form['ticker']
    start_date = request.form['start_date']
    end_date = request.form['end_date']
    
    # Call functions from standalone_code to perform sentiment analysis
    sentiment_breakdown = main_page.analyze_sentiment(ticker)
    sentiment_breakdown_json = json.dumps(sentiment_breakdown)

    most_popular_sentiment = max(sentiment_breakdown, key=sentiment_breakdown.get)
    
    # Load the trained LSTM model and scaler
    model = ann_lstm_multitrain.LSTMModel()
    model.load_model('media/lstm_model.h5')
    model.load_scaler('media/scaler.pkl')

    # Use the trained model for prediction
    lstm_result_direction, lstm_result_price = model.predict_price(ticker, start_date, end_date)
    action = main_page.determine_action(sentiment_breakdown, lstm_result_direction)
    
    # Return the prediction data as JSON response
    return jsonify(ticker=ticker, sentiment_breakdown=sentiment_breakdown_json,
                   most_popular_sentiment=most_popular_sentiment,
                   lstm_result_direction=lstm_result_direction, lstm_result_price=lstm_result_price,
                   action=action)

@app.route('/plot')
def plot():
    # Serve the image file "model_plot.png" located in the media folder
    return send_file('media/model_plot.png', mimetype='image/png')


@app.route('/prediction_result')
def prediction_result():
    ticker = request.args.get('ticker')
    sentiment_breakdown_str = request.args.get('sentiment_breakdown')
    sentiment_breakdown = json.loads(sentiment_breakdown_str)
    lstm_result_direction = request.args.get('lstm_result_direction')
    lstm_result_price = request.args.get('lstm_result_price')
    action = request.args.get('action')
    most_popular_sentiment = request.args.get('most_popular_sentiment')
    
    return render_template('prediction_result.php', ticker=ticker,
                           sentiment_breakdown=sentiment_breakdown,
                           most_popular_sentiment=most_popular_sentiment,
                           lstm_result_direction=lstm_result_direction,
                           lstm_result_price = lstm_result_price,
                           action=action)

if __name__ == '__main__':
    app.run(debug=True)
