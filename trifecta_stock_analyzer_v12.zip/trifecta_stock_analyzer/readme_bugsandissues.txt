How to Use:
Command - python main_page_py:
1. Enter a ticker, start date, and end date to train a model.
     -Start date being any date post-1970.
     -End date being any date up to the present
        >A month to a year before today would be ideal.
2. The trained model will be saved within the media folder.
3. Enter a ticker, start date, and end date to predict the direction/action
	-The ticker being the same ticker as the previous entry
	-Start Date being whichever end date you've decided upon
	-End date being as recent as today.
4. The terminal should display direction, the sentiment breakdown, the most popular sentiment, predicted closing price of today/tomorrow, and a suggested action

Command - python ann_display_2.py:
1. Search "http://localhost:5000/" in your web browser.
2. Enter a ticker, start date, and end date to train a model.
     -Start date being any date post-1970.
     -End date being any date up to the present
        >A month to a year before today would be ideal.
3. The trained model will be saved within the media folder.
4. Enter a ticker, start date, and end date to predict the direction/action
	-Start Date being whichever end date you've decided upon
	-End date being as recent as today.
5. The "prediction_result.html" page should display direction, the sentiment breakdown, the most popular sentiment, predicted closing price of today/tomorrow, and a suggested action





Functions:
index.html (Functional)- The main page. It hosts the form that collects the data from a user to submit to the main_page.py

error.html/loading.html (Obsolete) - Two pages created in the original iteration of the website to handle errors and lagtimes. Possibly obsolete in its current iteration, but still trying to make that determination.

prediction_result.html (Functional) - This page hosts the data and findings of the predictive model. 

ann_display_2.py (Functional) - This page hosts all of the routes that allow the HTML pages to interact with the Python pages. Routes such as train_model and predict_stock take the information from index.html and sends them into the main_page.py, which then transfers the information into the two machines, and returns its input to the HTML pages.

ann_lstm_multitrain.py (Functional) - The LSTM ANN machine. It receives a ticker, start date, and end date to both train a stock market data model and predict the direction of the stock market, providing both a direction and a supposed closing price. This page generates a .h5 file, a .pkl file, and a .png file. 

sent_anal_3.py (Functional) - The sentiment analysis page, it reads the news articles from finviz, receiving only the ticker from whichever page calls its method. After which, it returns a breakdown of the articles. This page generates a .csv file

main_page.py (Functional) - A hub page that connects the ANN machine with the Sentiment Analysis machine, funneling the results into a conditional method that determines whether or not one should buy/sell/hold




Problems (in order of importance):
A) (Resolved - 3/21/24) While the Flask page returns the breakdown to the user, it is only presented in the terminal. However, this information is not carried into the "prediction_result.html" page.

B) (Resolved - 4/1/24) The model plot.png looks janky. The predicted data is presented in the 1970s, instead of side-by-side with the actual information. 





Negligible Errors:
1) No matter what the date range is, the sentiment analysis will continue to provide either good or neutral news. Unless something catastrophic happens within the upcoming week, the tone of the news will continue to influence a buyer to buy or hold off on buying a certain stock. This is because the website we're using, FinViz, has a limited news scope. Unfortunately, this will influence our results. However, if we were to advance our research into finding financial news sites w/o data-scraping protections, we theorize that this will improve the results of our website.


2) Certain stocks will not show up in the sentiment analysis machine, but will show up in the YFinance library. This is because certain stocks have either been pulled from the stock market (i.e. BBBY, Bed Bath and Beyond) or not in the FinViz database (i.e., DKDRF, Newmed Energy LP).




