from urllib.request import urlopen, Request
from bs4 import BeautifulSoup
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pandas as pd
import datetime

class SentimentAnalysisModel:
    def __init__(self):
        nltk.download('vader_lexicon')
        self.vader = SentimentIntensityAnalyzer()
        self.finviz_url = 'https://finviz.com/quote.ashx?t='
        self.today_date = datetime.datetime.today().strftime('%b-%d-%y')
        self.news_tables = {}

    def fetch_news_data(self, tickers):
        for ticker in tickers:
            url = self.finviz_url + ticker
            req = Request(url=url, headers={'user-agent': 'my-app'})
            response = urlopen(req)
            html = BeautifulSoup(response, features="lxml")
            news_table = html.find(id='news-table')
            self.news_tables[ticker] = news_table

    def parse_news_data(self):
        parsed_data = []
        last_date = None  

        for ticker, news_table in self.news_tables.items():
            if news_table:
                for row in news_table.findAll('tr'):
                    title_cell = row.a
                    if title_cell:
                        title = title_cell.text
                        cells = row.findAll('td')  
                        if len(cells) > 1:  
                            date_time_str = cells[0].text  
                            date_time_list = date_time_str.split()  

                            if len(date_time_list) >= 2:
                                date = date_time_list[0]
                                time = date_time_list[1]
                            else:
                                date = date_time_list[0]
                                time = 'N/A'  

                            if date == 'Today':
                                date = self.today_date

                            if last_date is None or date != last_date:
                                last_date = date

                            # Calculate sentiment score
                            sentiment_score = self.vader.polarity_scores(title)['compound']

                            # Categorize sentiment
                            if sentiment_score >= 0.05:
                                sentiment_category = 'Positive'
                            elif sentiment_score <= -0.05:
                                sentiment_category = 'Negative'
                            else:
                                sentiment_category = 'Neutral'

                            parsed_data.append([ticker, last_date, time, title, sentiment_score, sentiment_category])

        df = pd.DataFrame(parsed_data, columns=['ticker', 'date', 'time', 'title', 'sentiment_score', 'sentiment_category'])
        df['date'] = pd.to_datetime(df['date'])  # Convert date column to datetime type

        return df

    # Inside analyze_sentiment method of SentimentAnalysisModel class
    def analyze_sentiment(self, ticker):
        self.fetch_news_data([ticker])  
        df = self.parse_news_data()  


        df['date'] = pd.to_datetime(df['date'], format='%b-%d-%y')
        
        # Use .loc to avoid SettingWithCopyWarning
        df.loc[:, 'sentiment_score'] = df['title'].apply(lambda x: self.vader.polarity_scores(x)['compound'])

        def categorize_sentiment(compound_score):
            if compound_score >= 0.05:
                return 'positive'
            elif compound_score <= -0.05:
                return 'negative'
            else:
                return 'neutral'

        df.loc[:, 'sentiment_category'] = df['sentiment_score'].apply(categorize_sentiment)

        sentiment_counts = df['sentiment_category'].value_counts()

        total_articles = len(df)

        sentiment_counts_percentages = {
            'Positive': (sentiment_counts.get('positive', 0) / total_articles) * 100,
            'Negative': (sentiment_counts.get('negative', 0) / total_articles) * 100,
            'Neutral': (sentiment_counts.get('neutral', 0) / total_articles) * 100,
            'Other': ((total_articles - sum(sentiment_counts)) / total_articles) * 100
        }

        return sentiment_counts_percentages



        
    def main(self):
        ticker = input("Enter a ticker symbol: ")
        self.fetch_news_data([ticker])
        df = self.parse_news_data()

        df['date'] = df['date'].dt.strftime('%Y-%m-%d')

        df.to_csv('media/news_data.csv', index=False)  # Save all data to a CSV file in 'media' directory

        writer = pd.ExcelWriter('media/news_data_2.xlsx', engine='xlsxwriter')
        df.to_excel(writer, index=False, sheet_name='Sheet1')
        workbook = writer.book
        worksheet = writer.sheets['Sheet1']
        date_format = workbook.add_format({'num_format': 'yyyy-mm-dd'})
        worksheet.set_column('A:A', None, date_format)
        writer._save()
        sentiment_breakdown = self.analyze_sentiment(ticker)
        if sentiment_breakdown:
            print("Sentiment Analysis Breakdown:")
            for sentiment, percentage in sentiment_breakdown.items():
                print(f"{sentiment.capitalize()}: {percentage:.2f}%")
            most_popular_sentiment = max(sentiment_breakdown, key=sentiment_breakdown.get)
            print("Most Popular Sentiment:", most_popular_sentiment.capitalize())


if __name__ == "__main__":
    SentimentAnalysisModel().main()
