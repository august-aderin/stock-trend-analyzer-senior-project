import requests
from bs4 import BeautifulSoup
import datetime
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

class SentimentAnalysisModel:
    def __init__(self):
        nltk.download('vader_lexicon')
        self.vader = SentimentIntensityAnalyzer()
        self.today_date = datetime.datetime.today().strftime('%b-%d-%y')

    def fetch_news_data(self, ticker):
        url = f"https://finance.yahoo.com/quote/{ticker}/news/"
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            headlines = soup.find_all('h3', class_='Mb(5px)')
            news_headlines = [headline.text for headline in headlines]
            return news_headlines
        else:
            print(f"Failed to fetch news headlines for {ticker}.")
            return []

    def analyze_sentiment(self, ticker):
        news_headlines = self.fetch_news_data(ticker)
        if not news_headlines:
            print(f"No news headlines found for {ticker}.")
            return None

        sentiment_scores = [self.vader.polarity_scores(headline)['compound'] for headline in news_headlines]
        average_sentiment = sum(sentiment_scores) / len(sentiment_scores)
        
        return average_sentiment

if __name__ == "__main__":
    model = SentimentAnalysisModel()
    ticker = input("Enter a ticker symbol: ")
    average_sentiment = model.analyze_sentiment(ticker)
    if average_sentiment is not None:
        print("Average Sentiment Score:", average_sentiment)
