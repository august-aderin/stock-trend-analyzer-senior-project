from urllib.request import urlopen, Request
from bs4 import BeautifulSoup
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pandas as pd
import datetime

class SentimentAnalysisModel:
    def __init__(self):
        nltk.download('vader_lexicon')
        self.vader = SentimentIntensityAnalyzer()
        self.finviz_url = 'https://finviz.com/quote.ashx?t='
        self.today_date = datetime.datetime.today().strftime('%b-%d-%y')
        self.news_tables = {}

    def fetch_news_data(self, tickers):
        for ticker in tickers:
            url = self.finviz_url + ticker
            req = Request(url=url, headers={'user-agent': 'my-app'})
            response = urlopen(req)
            html = BeautifulSoup(response, features="lxml")
            news_table = html.find(id='news-table')
            self.news_tables[ticker] = news_table

    def parse_news_data(self, start_date, end_date):
        parsed_data = []

        for ticker, news_table in self.news_tables.items():
            if news_table:
                for row in news_table.findAll('tr'):
                    title_cell = row.a
                    if title_cell:
                        title = title_cell.text
                        cells = row.findAll('td')
                        if len(cells) > 1:
                            date_time_str = cells[0].text
                            date_time_list = date_time_str.split()

                            if len(date_time_list) >= 2:
                                date = date_time_list[0]
                                time = date_time_list[1]
                            else:
                                date = date_time_list[0]
                                time = 'N/A'

                            if date == 'Today':
                                date = self.today_date

                            if start_date <= date <= end_date:
                                parsed_data.append([ticker, date, time, title])

        df = pd.DataFrame(parsed_data, columns=['ticker', 'date', 'time', 'title'])
        df.to_csv('news_data.csv', index=False)  # Save news data to a CSV file

        return 'news_data.csv'  # Return the filename

    def analyze_sentiment(self, news_data):
        df = pd.read_csv(news_data)  # Read news data from CSV file
        total_articles = len(df)

        if total_articles == 0:
            print("No news articles found within the specified date range.")
            return None

        df['sentiment_score'] = df['title'].apply(lambda x: self.vader.polarity_scores(x)['compound'])

        def categorize_sentiment(compound_score):
            if compound_score >= 0.05:
                return 'Positive'
            elif compound_score <= -0.05:
                return 'Negative'
            else:
                return 'Neutral'

        df['sentiment_category'] = df['sentiment_score'].apply(categorize_sentiment)

        sentiment_counts = df['sentiment_category'].value_counts()

        sentiment_counts_percentages = {
            'Positive': (sentiment_counts.get('Positive', 0) / total_articles) * 100,
            'Negative': (sentiment_counts.get('Negative', 0) / total_articles) * 100,
            'Neutral': (sentiment_counts.get('Neutral', 0) / total_articles) * 100,
            'Other': ((total_articles - sum(sentiment_counts)) / total_articles) * 100
        }

        df.to_csv('sentiment_analysis_result.csv', index=False)  # Save sentiment analysis result to a CSV file

        return sentiment_counts_percentages

if __name__ == "__main__":
    model = SentimentAnalysisModel()
    ticker = input("Enter a ticker symbol: ")
    start_date = input("Enter the start date (YYYY-MM-DD): ")
    end_date = input("Enter the end date (YYYY-MM-DD): ")
    tickers = [ticker]
    news_data_file = model.parse_news_data(start_date, end_date)
    sentiment_percentages = model.analyze_sentiment(news_data_file)
    if sentiment_percentages is not None:
        print("Sentiment Analysis Result:")
        for sentiment, percentage in sentiment_percentages.items():
            print(f"{sentiment}: {percentage:.2f}%")
