import numpy as np
import pandas_datareader as web
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential, load_model
import matplotlib.pyplot as plt
from keras.layers import Dense, LSTM
import yfinance as yf 
import math
from sklearn.metrics import mean_squared_error

plt.style.use('fivethirtyeight')

class LSTMModel:
    def predict_direction(self, pred_price, last_price):  
        price_difference = pred_price - last_price 
        percentage_difference = (price_difference / last_price) * 100 
        if abs(percentage_difference) <= 1: 
            direction = "Hold"
        elif abs(percentage_difference) <= 2:
            direction = "Light Buy" if percentage_difference > 0 else "Light Sell"
        elif abs(percentage_difference) <= 7:
            direction = "Medium Buy" if percentage_difference > 0 else "Medium Sell"
        else:
            direction = "Heavy Buy" if percentage_difference > 0 else "Heavy Sell"
        
        return direction

    def predict_price(self, ticker, start_date, end_date):
        try:
            df = yf.download(ticker, start=start_date, end=end_date)
        except ValueError:
            print(f"Error: Failed to download data for {ticker}. Please check the ticker symbol and try again.")
            return None, None, None
        
        data = df.filter(['Close'])
        data['Date'] = df.index  # Add the date column

        dataset = data['Close'].values.reshape(-1, 1)
        training_data_len = math.ceil(len(dataset) * .8)
        scaler = MinMaxScaler(feature_range=(0,1))
        scaled_data = scaler.fit_transform(dataset)

        train_data = scaled_data[0:training_data_len, :]
        x_train = []
        y_train = []

        for i in range(60, len(train_data)):
            x_train.append(train_data[i-60:i,0])
            y_train.append(train_data[i,0])

        x_train, y_train = np.array(x_train), np.array(y_train)

        if len(x_train) > 0:
            x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))

        model = Sequential()
        model.add(LSTM(50, return_sequences=True, input_shape=(x_train.shape[1], 1)))
        model.add(LSTM(50, return_sequences=False))
        model.add(Dense(25, activation='relu'))
        model.add(Dense(1, activation='linear'))
        model.add(Dense(25))
        model.add(Dense(1))

        model.compile(optimizer='adam',loss='mean_squared_error')
        model.fit(x_train, y_train, batch_size=32, epochs=50)

        test_data = scaled_data[training_data_len - 60: , :]
        x_test = []

        for i in range(60, len(test_data)):
            x_test.append(test_data[i-60:i, 0])

        x_test = np.array(x_test)
        x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))

        predictions = model.predict(x_test)
        predictions = scaler.inverse_transform(predictions)

        last_price = data.iloc[-1]['Close']

        direction = self.predict_direction(predictions[-1], last_price)

        train = data[:training_data_len]
        valid = data[training_data_len:]
        valid['Predictions'] = predictions

        # Save plot
        plt.figure(figsize=(16,8))
        plt.title(f'{ticker} Model')
        plt.xlabel('Date',fontsize=18)
        plt.ylabel('Close Price USD ($)', fontsize=18)
        plt.plot(train['Close'])
        plt.plot(valid[['Close','Predictions']])
        plt.legend(['Train', 'Val','Predictions'], loc='lower right')
        plot_file_path = f'media/model_plot.png'
        plt.savefig(plot_file_path)
        plt.close()

        # Save model
        model.save(f'media/lstm_model.h5')

        # Return direction, plot URL, and prediction data
        plot_url = plot_file_path
        prediction_data = valid.to_dict(orient='records')
        return direction, plot_url, prediction_data

if __name__ == "__main__":
    model = LSTMModel()
    ticker = input("Enter a ticker: ")
    start_date = input("Enter the start date (YYYY-MM-DD): ")
    end_date = input("Enter the end date (YYYY-MM-DD): ")
    direction, plot_url, prediction_data = model.predict_price(ticker, start_date, end_date)
    print("Predicted direction:", direction)
