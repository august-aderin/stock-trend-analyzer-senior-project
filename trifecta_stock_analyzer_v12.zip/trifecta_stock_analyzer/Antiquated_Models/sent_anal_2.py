# sent_anal_2.py

from urllib.request import urlopen, Request
from bs4 import BeautifulSoup
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import pandas as pd
import datetime

class SentimentAnalysisModel:
    def __init__(self):
        nltk.download('vader_lexicon')
        self.vader = SentimentIntensityAnalyzer()
        self.finviz_url = 'https://finviz.com/quote.ashx?t='
        self.today_date = datetime.datetime.today().strftime('%b-%d-%y')
        self.news_tables = {}

    def fetch_news_data(self, tickers):
        for ticker in tickers:
            url = self.finviz_url + ticker
            req = Request(url=url, headers={'user-agent': 'my-app'})
            response = urlopen(req)
            html = BeautifulSoup(response, features="lxml")
            news_table = html.find(id='news-table')
            self.news_tables[ticker] = news_table

    def parse_news_data(self):
        parsed_data = []
        last_date = None  

        for ticker, news_table in self.news_tables.items():
            if news_table:
                for row in news_table.findAll('tr'):
                    title_cell = row.a
                    if title_cell:
                        title = title_cell.text
                        cells = row.findAll('td')  
                        if len(cells) > 1:  
                            date_time_str = cells[0].text  
                            date_time_list = date_time_str.split()  

                            if len(date_time_list) >= 2:
                                date = date_time_list[0]
                                time = date_time_list[1]
                            else:
                                date = date_time_list[0]
                                time = 'N/A'  

                            if date == 'Today':
                                date = self.today_date

                            if last_date is None or date != last_date:
                                last_date = date

                            parsed_data.append([ticker, last_date, time, title])
                        else:
                            date = 'N/A'
                            time = 'N/A'

                            parsed_data.append([ticker, last_date, time, title])

        df = pd.DataFrame(parsed_data, columns=['ticker', 'date', 'time', 'title'])
        df['sentiment_score'] = df['title'].apply(lambda x: self.vader.polarity_scores(x)['compound'])

        def categorize_sentiment(compound_score):
            if compound_score >= 0.05:
                return 'Positive'
            elif compound_score <= -0.05:
                return 'Negative'
            else:
                return 'Neutral'

        df['sentiment_category'] = df['sentiment_score'].apply(categorize_sentiment)

        return df

    def analyze_sentiment(self, tickers):
        self.fetch_news_data(tickers)
        df = self.parse_news_data()

        sentiment_counts = df['sentiment_category'].value_counts()
        df.to_csv('news_with_sentiment.csv', index=False)

        sentiment_counts_dict = {
            'Positive': sentiment_counts.get('Positive', 0),
            'Negative': sentiment_counts.get('Negative', 0),
            'Neutral': sentiment_counts.get('Neutral', 0),
            'Other': len(df) - sum(sentiment_counts)
        }
        most_popular_sentiment = sentiment_counts.idxmax()

        return most_popular_sentiment
        
    def main(self):
        ticker = input("Enter a ticker symbol: ")
        tickers = [ticker]
        sentiment_result = self.analyze_sentiment(tickers)
        print("Sentiment Analysis Result:", sentiment_result)

if __name__ == "__main__":
    SentimentAnalysisModel().main()