import numpy as np
import pandas_datareader as web
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential, load_model
import matplotlib.pyplot as plt
from keras.layers import Dense, LSTM
import yfinance as yf 
import math
from sklearn.metrics import mean_squared_error

plt.style.use('fivethirtyeight')

class LSTMModel:
    def __init__(self, saved_model_path=None):
        self.model = None
        self.scaler = None
        self.plot_file_path = None
        if saved_model_path:
            self.load_model(saved_model_path)

    def load_model(self, saved_model_path):
        self.model = load_model(saved_model_path)

    def train_model(self, df):
        data = df.filter(['Close'])
        data['Date'] = df.index  # Add the date column

        dataset = data['Close'].values.reshape(-1, 1)
        training_data_len = math.ceil(len(dataset) * .8)
        self.scaler = MinMaxScaler(feature_range=(0,1))
        scaled_data = self.scaler.fit_transform(dataset)

        train_data = scaled_data[0:training_data_len, :]
        x_train = []
        y_train = []

        for i in range(60, len(train_data)):
            x_train.append(train_data[i-60:i,0])
            y_train.append(train_data[i,0])

        x_train, y_train = np.array(x_train), np.array(y_train)

        if len(x_train) > 0:
            x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))

        model = Sequential()
        model.add(LSTM(50, return_sequences=True, input_shape=(x_train.shape[1], 1)))
        model.add(LSTM(50, return_sequences=False))
        model.add(Dense(25, activation='relu'))
        model.add(Dense(1, activation='linear'))
        model.compile(optimizer='adam', loss='mean_squared_error')
        model.fit(x_train, y_train, batch_size=32, epochs=50)
        self.model = model

    def predict_direction(self, pred_price, last_price):  
        price_difference = pred_price - last_price 
        percentage_difference = (price_difference / last_price) * 100 
        if abs(percentage_difference) <= 1: 
            direction = "Hold"
        elif abs(percentage_difference) <= 2:
            direction = "Light Buy" if percentage_difference > 0 else "Light Sell"
        elif abs(percentage_difference) <= 7:
            direction = "Medium Buy" if percentage_difference > 0 else "Medium Sell"
        else:
            direction = "Heavy Buy" if percentage_difference > 0 else "Heavy Sell"
        
        return direction

    def generate_and_save_plot(self, df, predictions):
        data = df.copy()
        data['Predictions'] = predictions

        # Plot the data
        plt.figure(figsize=(16,8))
        plt.title(f'{ticker} Model')
        plt.xlabel('Date', fontsize=18)
        plt.ylabel('Close Price USD ($)', fontsize=18)
        plt.plot(data['Close'])
        plt.plot(data['Predictions'])
        plt.legend(['Actual', 'Predicted'], loc='lower right')
        
        # Save the plot
        self.plot_file_path = f'media/model_plot.png'  # Assuming the 'media' directory is served by Flask
        plt.savefig(self.plot_file_path)
        plt.close()

        return self.plot_file_path
    
    def predict_price(self, df):
        if self.model is None or self.scaler is None:
            raise ValueError("Model has not been trained. Please train the model first.")

        data = df[['Close']]  # Select only the 'Close' price column
        scaled_data = self.scaler.transform(data)

        print("Shape of df:", df.shape)  # Debug print
        test_data = scaled_data[-60:, :]  # Assuming you are using the last 60 data points for testing
        print("Shape of test_data:", test_data.shape)  # Debug print

        x_test = []

        for i in range(60, len(test_data)):
            x_test.append(test_data[i-60:i, 0])

        x_test = np.array(x_test)
        print("Shape of x_test before reshaping:", x_test.shape)  # Debug print
        
        if len(x_test) == 0:
            raise ValueError("No test data available for prediction.")

        x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))
        print("Shape of x_test after reshaping:", x_test.shape)   # Debug print

        # Generate predictions
        predictions = self.model.predict(x_test)
        predictions = self.scaler.inverse_transform(predictions)

        # Generate and save the plot
        plot_file_path = self.generate_and_save_plot(df, predictions)

        last_price = data.iloc[-1]['Close']
        direction = self.predict_direction(predictions[-1], last_price)

        return direction, predictions, plot_file_path





if __name__ == "__main__":
    model = LSTMModel()
    ticker = input("Enter a ticker: ")
    start_date = input("Enter the start date (YYYY-MM-DD): ")
    end_date = input("Enter the end date (YYYY-MM-DD): ")

    # Fetch data and train the model
    df = yf.download(ticker, start=start_date, end=end_date)
    model.train_model(df)

    # Now predict the price
    direction, predictions, plot_url = model.predict_price(df)
    print("Predicted direction:", direction)
