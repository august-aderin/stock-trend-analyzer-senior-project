<?php
session_start();
session_unset(); 
session_destroy(); 

header("Location: trifecta_login.php");
?>
