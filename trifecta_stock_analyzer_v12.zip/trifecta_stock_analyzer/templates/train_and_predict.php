<?php
session_start();


if (!isset($_SESSION['user'])) {

  header("Location: trifecta_login.php");
}

$loggedIn = isset($_SESSION['user']) && $_SESSION['user'] === true;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Price Prediction</title>
    <link rel="stylesheet" type="text/css" href="/static/css/styles.css">
    <style>
        /* Add custom CSS styles for loading bar and menu */
        .loading-bar {
            width: 100%;
            background-color: #f3f3f3;
            margin-bottom: 20px;
        }

        .loading-bar-fill {
            height: 20px;
            background-color: #4caf50;
            width: 0%;
            transition: width 0.3s ease-in-out; /* Add smooth transition */
        }

        .hidden {
            display: none;
        }

        /* Navigation bar styles */
        nav {
            background-color: #333;
            overflow: hidden;
        }

        nav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #ddd;
            color: black;
        }
    </style>
</head>
<body>
    <header>
        <h1>Trifecta Stock Analyzer</h1>
    </header>
    <nav>
            <a href="{{ url_for('index') }}">Home</a>
            <?php if ($loggedIn): ?>
                <a href="{{ url_for('trifecta_edit_profile') }}">Profile</a>
                <a href="{{ url_for('train_and_predict') }}">Stock Analyzer</a>
                <a href="{{ url_for('trifecta_logout') }}">Logout</a>
            <?php else: ?>
                <a href="{{ url_for('trifecta_login') }}">Login</a>
                <a href="{{ url_for('trifecta_sign_up') }}">Signup</a>
            <?php endif; ?>
    </nav>
    <section>
        <div id="trainingSection">
            <h2>Train the Model</h2>
            <form id="trainingForm" action="/train_model" method="POST">
                <label for="train_ticker">Enter a ticker for training:</label>
                <input type="text" id="train_ticker" name="train_ticker" required><br><br>
                <label for="train_start_date">Enter the start date for training (YYYY-MM-DD):</label>
                <input type="date" id="train_start_date" name="train_start_date" required><br><br>
                <label for="train_end_date">Enter the end date for training (YYYY-MM-DD):</label>
                <input type="date" id="train_end_date" name="train_end_date" required><br><br>
                <input type="submit" value="Train Model">
            </form>
            <div class="loading-bar hidden">
                <div class="loading-bar-fill" id="loadingBarFill"></div>
            </div>
        </div>
        <!-- Add prediction section -->
        <div id="predictionSection" class="hidden">
            <h2>Predict Stock Price</h2>
            <form id="predictionForm" action="/predict_stock" method="POST">
                <label for="ticker">Enter a ticker:</label>
                <input type="text" id="ticker" name="ticker" required><br><br>
                <label for="start_date">Enter the start date (YYYY-MM-DD):</label>
                <input type="date" id="start_date" name="start_date" required><br><br>
                <label for="end_date">Enter the end date (YYYY-MM-DD):</label>
                <input type="date" id="end_date" name="end_date" required><br><br>
                <input type="submit" value="Predict">
            </form>
        </div>
    </section>
    <footer>
        <p>&copy; 2024 Trifecta</p>
    </footer>

    <script>
        document.getElementById("trainingForm").addEventListener("submit", function(event){
            event.preventDefault();
            const form = event.target;
            const formData = new FormData(form);
            
            fetch("/train_model", {
                method: "POST",
                body: formData
            })
            .then(response => {
                if (response.ok) {
                    // If the response is successful, hide the training section and show the prediction section
                    document.getElementById("trainingSection").classList.add('hidden');
                    document.getElementById("predictionSection").classList.remove('hidden');
                    document.body.style.backgroundColor = '#e6e6e6'; // Change background color to light grey
                    document.querySelector('header').style.backgroundColor = '#2ecc71'; // Change header color to sea green
                } else {
                    // If there's an error, display an alert
                    alert("Training failed. Please try again.");
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("Training failed. Please try again.");
            });
        });
    
        document.getElementById("predictionForm").addEventListener("submit", function(event){
            event.preventDefault();
            const form = event.target;
            const formData = new FormData(form);
            
            fetch(form.action, {
                method: "POST",
                body: formData
            })
            .then(response => response.json()) // Parse JSON response
            .then(data => {
                // Redirect to the prediction result page with prediction data
                const params = new URLSearchParams(data); // Convert JSON data to URLSearchParams
                window.location.href = "{{ url_for('prediction_result') }}?" + params.toString(); // Redirect with URL parameters
            })
            .catch(error => {
                console.error('Error:', error);
                alert("Prediction failed. Please try again.");
            });
        });
    
        // Function to update loading bar width
        function updateLoadingBar(progress) {
            const loadingBarFill = document.getElementById("loadingBarFill");
            loadingBarFill.style.width = progress + "%";
        }
    </script>
    
</body>
</html>
