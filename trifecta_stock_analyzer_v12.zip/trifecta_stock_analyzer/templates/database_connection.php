<?php
$host = "localhost";
$username = "root"; 
$password = ""; 
$database = "trifecta_users"; 

$conn = new mysqli($host, $username, $password, $database);

?>
