<?php
// Start session
session_start();

// Include the database connection
include "database_connection.php";

// Define function to handle form submission and provide feedback
function handleFormSubmission() {
    global $conn;
    $info = ['type' => '', 'message' => ''];

    // Check if the request method is POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
        // Retrieve form data
        $name = $_POST['name'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['c_pass'];
        $email = $_POST['email'];
        $phoneNumber = $_POST['phoneNumber'];
        $plannedInvestment = $_POST['plannedInvestment'];
        $tradingStatus = $_POST['tradingStatus'];
        $stopLoss = $_POST['stopLoss'];

        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $info = [
                'type' => 'error',
                'message' => 'Invalid email format.'
            ];
            return $info;
        }

        // Validate phone number format
        if (!preg_match('/^\+?[0-9]{10,15}$/', $phoneNumber)) {
            $info = [
                'type' => 'error',
                'message' => 'Invalid phone number format.'
            ];
            return $info;
        }

        // Check if email already exists
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $info = [
                'type' => 'error',
                'message' => 'Email already exists.'
            ];
        } else {
            // Check if passwords match
            if ($password === $confirmPassword) {
                // Validate password strength (length, special characters, etc.)
                if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[!@#$%^&*]/', $password)) {
                    $info = [
                        'type' => 'error',
                        'message' => 'Password must be at least 8 characters long and contain uppercase letters, numbers, and special characters.'
                    ];
                    return $info;
                }

                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // Insert user data into the database
                $sql = "INSERT INTO users (name, password, email, phoneNumber, plannedInvestment, tradingStatus, stopLoss) VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('ssssiss', $name, $hashedPassword, $email, $phoneNumber, $plannedInvestment, $tradingStatus, $stopLoss);
                
                if ($stmt->execute()) {
                    $info = [
                        'type' => 'success',
                        'message' => 'Data saved successfully. Redirecting in 3 seconds...'
                    ];

                    // Redirect to the login page after 3 seconds
                    echo "<script>
                        setTimeout(function() {
                            window.location.href = '{{ url_for('trifecta_login') }}';
                        }, 3000);
                    </script>";
                } else {
                    $info = [
                        'type' => 'error',
                        'message' => 'An error occurred during data insertion.'
                    ];
                }
            } else {
                $info = [
                    'type' => 'error',
                    'message' => 'Password does not match confirmation password.'
                ];
            }
        }

        // Close statement
        $stmt->close();
    }

    return $info;
}

// Check if the user is logged in
$loggedIn = isset($_SESSION['username']) && $_SESSION['username'] === true;

// Get feedback from form submission
$info = handleFormSubmission();

// Close database connection
$conn->close();

// Output HTML content
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Sign-Up</title>
    <link rel="stylesheet" href="/static/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <header>
        <h1>Trifecta Stock Analyzer</h1>
    </header>

    <nav>
        <a href="{{ url_for('index') }}">Home</a>
        <?php if ($loggedIn): ?>
            <a href="{{ url_for('trifecta_edit_profile') }}">Profile</a>
            <a href="{{ url_for('train_and_predict') }}">Stock Analyzer</a>
            <a href="{{ url_for('trifecta_logout') }}">Logout</a>
        <?php else: ?>
            <a href="{{ url_for('trifecta_login') }}">Login</a>
            <a href="{{ url_for('trifecta_sign_up') }}">Signup</a>
        <?php endif; ?>
    </nav>

    <div class="container">
        <section>
            <h2>User Sign-Up</h2>
        </section>
        <!-- Display feedback messages -->
        <?php if ($info['message']): ?>
            <div class="alert alert-<?php echo $info['type'] === 'success' ? 'success' : 'error'; ?>">
                <?php echo $info['message']; ?>
            </div>
        <?php endif; ?>

        <!-- User sign-up form -->
        <form method="POST" class="signup-form">
            <div class="form-group">
                <label for="name">Username:</label>
                <input type="text" id="name" name="name" placeholder="Enter Username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter Password" required>
            </div>
            <div class="form-group">
                <label for="c_pass">Confirm Password:</label>
                <input type="password" id="c_pass" name="c_pass" placeholder="Confirm Password" required>
            </div>
            <div class="form-group">
                <label for="phoneNumber">Phone Number:</label>
                <input type="tel" id="phoneNumber" name="phoneNumber" placeholder="Enter Phone Number" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter Email Address" required>
            </div>
            <div class="form-group">
                <label for="plannedInvestment">Planned Investment:</label>
                <input type="number" id="plannedInvestment" name="plannedInvestment" placeholder="Enter Planned Investment" required>
            </div>
            <div class="form-group">
                <label for="stopLoss">Stop Loss:</label>
                <input type="number" id="stopLoss" name="stopLoss" placeholder="Enter Stop Loss" required>
            </div>
            <div class="form-group">
                <label for="tradingStatus">Trading Status:</label>
                <select id="tradingStatus" name="tradingStatus" required>
                    <option value="S">Spectator</option>
                    <option value="A">Amateur</option>
                    <option value="M">Moderate</option>
                    <option value="P">Professional</option>
                </select>
            </div>
            <div class="form-group">
                <input type="submit" value="Sign Up">
            </div>
        </form>
    </div>
</body>

</html>
