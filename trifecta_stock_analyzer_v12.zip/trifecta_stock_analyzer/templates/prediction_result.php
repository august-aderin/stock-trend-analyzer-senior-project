<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user']) || $_SESSION['user'] !== true) {
    // Redirect to the login page if the user is not logged in
    header("Location: trifecta_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="/static/css/styles.css">
    <title>Prediction Result</title>
</head>
<body>
   
    <header>
        <h1>Trifecta Stock Analyzer</h1>
    </header>
        <!-- Add navigation bar -->
        <nav>
            <a href="{{ url_for('index') }}">Home</a>
            <?php if ($loggedIn): ?>
                <a href="{{ url_for('trifecta_edit_profile') }}">Profile</a>
                <a href="{{ url_for('train_and_predict') }}">Stock Analyzer</a>
                <a href="{{ url_for('trifecta_logout') }}">Logout</a>
            <?php else: ?>
                <a href="{{ url_for('trifecta_login') }}">Login</a>
                <a href="{{ url_for('trifecta_sign_up') }}">Signup</a>
            <?php endif; ?>
    </nav>
    
    <section>
    <h2>Prediction Result for {{ ticker }}</h2>
    </section>
    <section>
        <h2>LSTM Prediction Graph:</h2>
        <p><img src="/plot" alt="Model Plot" width="1000" height="600" class="center"></p>
    </section>


    <!-- Sentiment Analysis Breakdown Table -->
    <section>
        <h2>Sentiment Analysis Breakdown:</h2>
        <table>
            <tr>
                <th>Sentiment</th>
                <th>Percentage</th>
            </tr>
            {% for sentiment, percentage in sentiment_breakdown.items() %}
            <tr>
                <td>{{ sentiment }}</td>
                <td>{{ percentage }}%</td>
            </tr>
            {% endfor %}
        </table>
    </section>

    <!-- Most Popular Sentiment Section -->
    <section>
        <h2>Most Popular Sentiment:</h2>
        <p>{{ most_popular_sentiment }}</p>
    </section>

    <!-- LSTM Model Prediction Section -->
    <section>
        <h2>LSTM Model Prediction -- Direction:</h2>
        <p>{{ lstm_result_direction }}</p>
    </section>

    <!-- LSTM Model Prediction Section -->
    <section>
        <h2>LSTM Model Prediction -- Price:</h2>
        <p>{{ lstm_result_price }}</p>
    </section>

    <!-- Action to Take Section -->
    <section>
        <h2>Action to take:</h2>
        <p>{{ action }}</p>
    </section>

</body>
</html>
