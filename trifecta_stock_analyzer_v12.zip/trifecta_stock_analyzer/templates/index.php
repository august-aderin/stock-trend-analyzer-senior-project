<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user']) || $_SESSION['user'] !== true) {
    // Redirect to the login page if the user is not logged in
    header("Location: trifecta_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Price Prediction</title>
    <link rel="stylesheet" type="text/css" href="/static/css/styles.css">
</head>

<body>
    <div class="container">
        <header>
        <h1>Trifecta Stock Analyzer</h1>
    </header>
        <!-- Add navigation bar -->
        <nav>
            <a href="{{ url_for('index') }}">Home</a>
            <?php if ($loggedIn): ?>
                <a href="{{ url_for('trifecta_edit_profile') }}">Profile</a>
                <a href="{{ url_for('train_and_predict') }}">Stock Analyzer</a>
                <a href="{{ url_for('info') }}">Logout</a>
            <?php else: ?>
                <a href="{{ url_for('trifecta_login') }}">Login</a>
                <a href="{{ url_for('trifecta_sign_up') }}">Signup</a>
            <?php endif; ?>
        </nav>
        <!-- Add your main page content here -->
        <p>Hello, Welcome to the Trifecta Stock Analyzer!</p>

        <!-- Add loading bar -->
        <div class="loading-bar">
            <div class="loading-bar-fill"></div>
        </div>

        <!-- Add additional content below -->
    </div>
</body>

</html>
