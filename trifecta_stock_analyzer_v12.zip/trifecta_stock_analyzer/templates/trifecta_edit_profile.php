<?php
// Include the database connection
include "database_connection.php";

// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: trifecta_login.php");
    exit();
}

// Get user ID from session
$loggedInUserId = $_SESSION['u_id'];

// Initialize info variable
$info = "";

// Validate and sanitize user inputs
function validate_input($data, $type = FILTER_SANITIZE_STRING) {
    return filter_var($data, $type);
}

// Check if form was submitted
if (isset($_POST['submit'])) {
    // Retrieve and sanitize form data
    $name = validate_input($_POST['name']);
    $password = validate_input($_POST['password']);
    $confirmPassword = validate_input($_POST['c_pass']);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $phoneNumber = validate_input($_POST['phoneNumber']);
    $plannedInvestment = filter_var($_POST['plannedInvestment'], FILTER_VALIDATE_FLOAT);
    $tradingStatus = validate_input($_POST['tradingStatus']);
    $stopLoss = filter_var($_POST['stopLoss'], FILTER_VALIDATE_FLOAT);

    if ($name && $email && $phoneNumber && $plannedInvestment && $tradingStatus && $stopLoss) {
        // Verify that password and confirm password match
        if ($password === $confirmPassword) {
            // Prepare statement for updating user data
            $stmt = $conn->prepare("UPDATE users SET name = ?, phoneNumber = ?, plannedInvestment = ?, tradingStatus = ?, stopLoss = ? WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("ssisdii", $name, $phoneNumber, $plannedInvestment, $tradingStatus, $stopLoss, $loggedInUserId);

                // Execute statement
                if ($stmt->execute()) {
                    $info = "<div class='alert alert-success'><strong>Profile updated successfully.</strong></div>";
                } else {
                    $info = "<div class='alert alert-danger'><strong>An error occurred while updating the profile.</strong></div>";
                }

                // Close statement
                $stmt->close();
            } else {
                $info = "<div class='alert alert-danger'><strong>Error preparing the statement.</strong></div>";
            }
        } else {
            $info = "<div class='alert alert-danger'><strong>Passwords do not match.</strong></div>";
        }
    } else {
        $info = "<div class='alert alert-danger'><strong>Invalid form data.</strong></div>";
    }
}

// Close database connection
$conn->close();

// Output info message if any
if (!empty($info)) {
    echo $info;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>User Sign-Up</title>
    <link rel="stylesheet" href="/static/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <header>
        <h1>Trifecta Stock Analyzer</h1>
    </header>

    <nav>
        <a href="{{ url_for('index') }}">Home</a>
        <?php if ($loggedIn): ?>
            <a href="{{ url_for('trifecta_edit_profile') }}">Profile</a>
            <a href="{{ url_for('train_and_predict') }}">Stock Analyzer</a>
            <a href="{{ url_for('trifecta_logout') }}">Logout</a>
        <?php else: ?>
            <a href="{{ url_for('trifecta_login') }}">Login</a>
            <a href="{{ url_for('trifecta_sign_up') }}">Signup</a>
        <?php endif; ?>
    </nav>

<main>
  <div class="form-container">
    <h2>Edit Profile</h2>
    <?php echo $info; ?>
    <form method="POST">
      <div class="form-group">
        <label for="name"><b>Username</b></label>
        <input type="text" name="name" value="<?php echo $name; ?>">
      </div>
      <div class="form-group">
        <label for="phoneNumber"><b>Phone Number</b></label>
        <input type="text" name="phoneNumber" value="<?php echo $phoneNumber; ?>">
      </div>
      <div class="form-group">
        <label for="email"><b>Email Address</b></label>
        <input type="text" name="email" value="<?php echo $email; ?>" disabled>
      </div>
      <div class="form-group">
        <label for="plannedInvestment"><b>Planned Investment</b></label>
        <input type="text" name="plannedInvestment" value="<?php echo $plannedInvestment; ?>">
      </div>
      <div class="form-group">
        <label for="stopLoss"><b>Stop Loss</b></label>
        <input type="text" name="stopLoss" value="<?php echo $stopLoss; ?>">
      </div>
      <div class="form-group">
        <label for="status">What Are You?:</label>
        <select id="status" name="status">
          <option value="R" <?php if (isset($userData['tradingStatus']) && $userData['tradingStatus'] === 'S') echo 'selected'; ?>>Spectator</option>
          <option value="C" <?php if (isset($userData['tradingStatus']) && $userData['tradingStatus'] === 'A') echo 'selected'; ?>>Amateur</option>
          <option value="F" <?php if (isset($userData['tradingStatus']) && $userData['tradingStatus'] === 'M') echo 'selected'; ?>>Moderate</option>
          <option value="V" <?php if (isset($userData['tradingStatus']) && $userData['tradingStatus'] === 'P') echo 'selected'; ?>>Professional</option>
        </select>
      </div>
      <button type="submit" name="submit" class="btn">Update Profile</button>
    </form>
  </div>
</main>

<footer>
 
</footer>

</body>
</html>