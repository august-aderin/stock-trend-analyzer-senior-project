<?php
include "database_connection.php";
session_start();

$info = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["pass"];

   
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result === false) {
        die("Query failed: " . $conn->error);
    }
if ($row = mysqli_fetch_assoc($result)) {
    $hashedPassword = $row["password"];
    if (password_verify($password, $hashedPassword)) {
        $_SESSION["user"] = true;
        $_SESSION['u_id'] = $row['id'];
        header('location:main_page.php');
    
    } else {
        $info = "<div class='alert alert-warning '>
        <strong>Incorrect password.</strong>
        
    </div>";
    }
} else {
$info = "<div class='alert alert-danger '>
    <strong>User not found.</strong>
    
</div>";
}
}
$loggedIn = isset($_SESSION['user']) && $_SESSION['user'] === true;

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="/static/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Trifecta Stock Analyzer</title>
</head>

<header>
    <h1>Trifecta Stock Analyzer</h1>
</header>
<nav>
            <a href="{{ url_for('index') }}">Home</a>
            <?php if ($loggedIn): ?>
                <a href="{{ url_for('trifecta_edit_profile') }}">Profile</a>
                <a href="{{ url_for('train_and_predict') }}">Stock Analyzer</a>
                <a href="{{ url_for('trifecta_logout') }}">Logout</a>
            <?php else: ?>
                <a href="{{ url_for('trifecta_login') }}">Login</a>
                <a href="{{ url_for('trifecta_sign_up') }}">Signup</a>
            <?php endif; ?>
    </nav>
<main>
        <div class="room-for-jesus"></div>

        <div class="form-container">
        <section>    
            <h2>Login</h2>
        </section>
        <?php echo $info; ?>
        <form method="POST">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required placeholder="Enter your Email...">
          </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="pass" required placeholder="Enter your password...">
            </div>
            <div class="form-group">
                <p>Don't have any account yet? <a href="{{ url_for('trifecta_sign_up') }}">Register Here</a> </p>
                <input type="submit" value="Login" name = "login">
            </div>
        </form>
    </div>
</main>
<footer>
        
        </div>
    </footer>    
    
    </div>
    </body>
    </html>