import sent_anal_3
import ann_lstm_multitrain
import yfinance as yf

def train_model(model, train_ticker, train_start_date, train_end_date):
    # Validate if stock data is available
    data = yf.download(train_ticker, start=train_start_date, end=train_end_date)
    if data.empty:
        print(f"Error: No data available for {train_ticker} from {train_start_date} to {train_end_date}.")
        return None
    
    model.train_model(train_ticker, train_start_date, train_end_date)
    return model

def analyze_sentiment(ticker):
    try:
        sentiment_model = sent_anal_3.SentimentAnalysisModel()
        return sentiment_model.analyze_sentiment(ticker)
    except Exception as e:
        print(f"Error analyzing sentiment for {ticker}: {e}")
        return None

def predict_stock_price(model, ticker, start_date, end_date):
    try:
        return model.predict_price(ticker, start_date, end_date)
    except Exception as e:
        print(f"Error predicting stock price for {ticker}: {e}")
        return None

def determine_action(sentiment_breakdown, lstm_result):
    if lstm_result is None or sentiment_breakdown is None:
        return "Prediction failed. Please check the inputs and try again."

    stock_movement = "stagnant"
    if "Rise" in lstm_result[0]:
        stock_movement = "up"
    elif "Fall" in lstm_result[0]:
        stock_movement = "down"

    most_popular_sentiment = max(sentiment_breakdown, key=sentiment_breakdown.get)
    news = most_popular_sentiment

    # Decision logic
    if news == "positive":
        if stock_movement == "up":
            return f"It's strongly recommended that you buy this stock. The news is {news} and the stock price is going {stock_movement}."
        elif stock_movement == "down":
            return f"It is not recommended to buy this stock. While the news is {news}, the stock price is going {stock_movement}."
        else:
            return f"It's recommended that you buy this stock. While the stock price is {stock_movement}, the news is {news}."
    elif news == "negative":
        if stock_movement == "up":
            return f"It's recommended to cautiously buy this stock. While the stock price is {stock_movement}, the news is {news}."
        elif stock_movement == "down":
            return f"It's strongly recommended that you sell this stock. The news is {news} and the stock price is going {stock_movement}."
        else:
            return f"It's recommended that you sell this stock. While the news is {news}, the stock price is {stock_movement}."
    else:  # Neutral news
        if stock_movement == "up":
            return f"It's recommended that you buy this stock. While the news is {news}, the stock price is going {stock_movement}."
        elif stock_movement == "down":
            return f"It's recommended that you sell this stock. While the news is {news}, the stock price is going {stock_movement}."
        else:
            return f"It's recommended that you watch this stock carefully. The news is {news} and the stock price is {stock_movement}."

def main():
    last_trained_ticker = None
    model = None

    while True:
        train_ticker = input("Enter a ticker to train the model: ").strip().upper()
        
        if train_ticker != last_trained_ticker or model is None:
            train_start_date = input("Enter the start date for training (YYYY-MM-DD): ").strip()
            train_end_date = input("Enter the end date for training (YYYY-MM-DD): ").strip()
            
            model = ann_lstm_multitrain.LSTMModel()
            model = train_model(model, train_ticker, train_start_date, train_end_date)
            
            if model is None:
                print("Model training failed. Try another ticker or date range.")
                continue  # Skip to next iteration
            
            last_trained_ticker = train_ticker
            print("Model trained successfully.")
        else:
            print("Using existing model. No need to retrain.")

        ticker = input("Enter a ticker symbol for prediction: ").strip().upper()
        start_date = input("Enter the start date (YYYY-MM-DD): ").strip()
        end_date = input("Enter the end date (YYYY-MM-DD): ").strip()

        sentiment_breakdown = analyze_sentiment(ticker)
        if sentiment_breakdown is None:
            print("Sentiment analysis failed. Skipping prediction.")
            continue

        lstm_result = predict_stock_price(model, ticker, start_date, end_date)

        if lstm_result:
            print("\nSentiment Analysis Breakdown:")
            for sentiment, percentage in sentiment_breakdown.items():
                print(f"{sentiment}: {percentage:.2f}%")
            most_popular_sentiment = max(sentiment_breakdown, key=sentiment_breakdown.get)
            print("Most Popular Sentiment:", most_popular_sentiment)
            print("LSTM Model Prediction:", lstm_result)

        action = determine_action(sentiment_breakdown, lstm_result)
        print("\nAction to take:", action)

        exit_choice = input("\nDo you want to continue (Yes/No)?: ").strip().lower()
        if exit_choice == "no":
            break

if __name__ == '__main__':
    main()
